# GuardianLayer 🛡️

**Centralized control plane for app lifecycle management** — deployments, backups, agents, rollbacks, and observability in one place.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    GuardianLayer API                     │
│                   (FastAPI on Replit)                    │
│                                                          │
│  /apps  /deploy  /backup  /agents  /incidents  /metrics  │
└────────┬─────────────────────────────────────┬──────────┘
         │                                     │
    ┌────▼────┐                         ┌──────▼──────┐
    │ Postgres │                         │ Redis + RQ  │
    │   DB     │                         │  Workers    │
    └──────────┘                         └──────┬──────┘
                                                │
              ┌─────────────────────────────────┤
              │              │                  │
       ┌──────▼─────┐ ┌─────▼──────┐  ┌───────▼──────┐
       │ Deploy Job  │ │ Backup Job │  │  Agent Jobs  │
       │ SSH+Docker  │ │  pg_dump   │  │  CodeGuard   │
       │  on VPS     │ │  → S3/R2   │  │  UpgradeBot  │
       └─────────────┘ └────────────┘  └──────────────┘
```

---

## Quick Start on Replit

### 1. Fork / Import this Repl

Import from GitHub or create a new Python Repl and upload all files.

### 2. Configure Secrets

Click the 🔒 **Secrets** tab in Replit and add these (see `.env.example` for all options):

| Secret | Required | Description |
|--------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string (Supabase/Neon free tier works) |
| `REDIS_URL` | ✅ | Redis URL (Upstash free tier recommended) |
| `SECRET_KEY` | ✅ | Long random string for token signing |
| `SSH_PRIVATE_KEY_B64` | For deploy | Base64 SSH key for VPS access |
| `GITHUB_TOKEN` | For agents | GitHub fine-grained PAT |
| `BACKUP_BUCKET` | For backups | S3/R2 bucket name |
| `TELEGRAM_BOT_TOKEN` | For alerts | Get from @BotFather |

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the API

```bash
uvicorn main:app --host 0.0.0.0 --port 8080 --reload
```

The first time it starts, it prints a **bootstrap admin token** to the logs — copy it immediately.

### 5. Run the Worker (separate tab)

```bash
python worker.py
```

Open a second Shell tab in Replit and run the worker there.

---

## API Usage

### Authenticate

All endpoints require a Bearer token:
```bash
export TOKEN="your-token-here"
curl -H "Authorization: Bearer $TOKEN" https://your-repl.replit.app/api/v1/apps
```

### Register an App

```bash
curl -X POST https://your-repl.replit.app/api/v1/apps \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-app",
    "repo_url": "https://github.com/you/my-app",
    "environment": "production",
    "vps_host": "deploy@123.456.789.0",
    "vps_port": 22,
    "container_name": "my-app",
    "image_name": "ghcr.io/you/my-app",
    "exposed_port": 3000
  }'
```

### Trigger a Deployment

```bash
curl -X POST https://your-repl.replit.app/api/v1/apps/1/deploy \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"version": "abc1234", "image_tag": "ghcr.io/you/my-app:abc1234"}'
```

### Trigger a Backup

```bash
curl -X POST https://your-repl.replit.app/api/v1/apps/1/backup \
  -H "Authorization: Bearer $TOKEN"
```

### Set a Backup Policy (nightly at 3am)

```bash
curl -X POST https://your-repl.replit.app/api/v1/apps/1/backup-policy \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "app_id": 1,
    "backup_type": "full",
    "schedule": "0 3 * * *",
    "retention_days": 7,
    "enabled": true
  }'
```

### Run an Agent

```bash
# Available: health_check, code_guardian, upgrade, database
curl -X POST https://your-repl.replit.app/api/v1/agents/code_guardian/run/1 \
  -H "Authorization: Bearer $TOKEN"
```

### Manual Rollback

```bash
curl -X POST https://your-repl.replit.app/api/v1/apps/1/rollback \
  -H "Authorization: Bearer $TOKEN"
```

### GitHub Webhook (auto-deploy on push)

Set your GitHub repo webhook URL to:
```
https://your-repl.replit.app/api/v1/webhooks/github/{app_id}
```
Content type: `application/json` — triggers deploy on pushes to `main`/`master`.

---

## Automatic Schedules

| Job | Schedule | Description |
|-----|----------|-------------|
| Health Check | Every 5 min | HTTP ping all running apps |
| CodeGuardian | 2am UTC nightly | GitHub security/Dependabot scan |
| UpgradeAgent | Sunday 3am UTC | Check dep alerts, open PRs |
| Backup | Per policy | Configurable per-app cron |

---

## Observability

- **Prometheus metrics**: `GET /metrics`
- **Interactive API docs**: `GET /docs` (Swagger UI)
- **Health check**: `GET /health`
- **Incidents log**: `GET /api/v1/incidents`

---

## Database Setup Options (free tiers)

| Provider | Notes |
|----------|-------|
| [Supabase](https://supabase.com) | 500MB free PostgreSQL |
| [Neon](https://neon.tech) | Serverless Postgres, free tier |
| [Railway](https://railway.app) | $5/month, very easy |
| SQLite | Works locally, not for production |

## Redis Options (free tiers)

| Provider | Notes |
|----------|-------|
| [Upstash](https://upstash.com) | Serverless Redis, 10k requests/day free |
| [Redis Cloud](https://redis.com) | 30MB free |

---

## SSH Key Setup (for VPS deployments)

```bash
# 1. Generate a deploy key pair
ssh-keygen -t rsa -b 4096 -C "guardianLayer-deploy" -f ~/.ssh/guardian_deploy

# 2. Add public key to your VPS
ssh-copy-id -i ~/.ssh/guardian_deploy.pub deploy@your-vps

# 3. Base64-encode the private key for Replit Secret
cat ~/.ssh/guardian_deploy | base64 -w 0
# Paste output as SSH_PRIVATE_KEY_B64 in Replit Secrets
```

---

## File Structure

```
guardianLayer/
├── main.py           # FastAPI app, startup, middleware
├── config.py         # All settings (from Replit Secrets)
├── database.py       # SQLModel/PostgreSQL setup
├── models.py         # All data models (App, Deploy, Backup, etc.)
├── auth.py           # API token auth
├── routers.py        # All API endpoints
├── deploy_engine.py  # SSH Docker deployment logic
├── backup_engine.py  # pg_dump + S3/R2 upload logic
├── agents.py         # HealthCheck, CodeGuardian, Upgrade, DB agents
├── scheduler.py      # APScheduler cron jobs
├── queue_manager.py  # Redis + RQ setup
├── ssh_helper.py     # Paramiko SSH utility
├── notifications.py  # Telegram + Twilio alerts
├── worker.py         # RQ worker startup script
├── requirements.txt
└── .env.example
```
