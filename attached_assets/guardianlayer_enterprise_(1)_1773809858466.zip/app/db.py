
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

engine = create_engine("sqlite:///guardian.db")
SessionLocal = sessionmaker(bind=engine)
