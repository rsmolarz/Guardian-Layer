
from fastapi import FastAPI
from app.api import payments, approval, webhook, integrations
from app.dashboard import router as dashboard_router

app = FastAPI(title="GuardianLayer Enterprise")

app.include_router(payments.router, prefix="/payments")
app.include_router(approval.router, prefix="/approval")
app.include_router(webhook.router, prefix="/webhook")
app.include_router(integrations.router, prefix="/integrations")
app.include_router(dashboard_router, prefix="/dashboard")

@app.get("/")
def root():
    return {"status": "enterprise running"}
