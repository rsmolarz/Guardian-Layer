
from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter()

@router.get("/", response_class=HTMLResponse)
def dash():
    return "<h1>Guardian Enterprise Dashboard</h1>"
