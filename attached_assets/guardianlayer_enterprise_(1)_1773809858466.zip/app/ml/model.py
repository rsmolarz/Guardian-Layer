
import random

def predict(features):
    return random.uniform(0,1)
