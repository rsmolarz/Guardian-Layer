
from fastapi import APIRouter
from app.ml.model import predict

router = APIRouter()

@router.post("/send")
def send(txn: dict):
    risk = predict(txn)
    if risk > 0.7:
        return {"status":"HELD","risk":risk}
    return {"status":"ALLOWED","risk":risk}
