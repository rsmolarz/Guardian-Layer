
from fastapi import APIRouter
router = APIRouter()

@router.post("/twilio")
def twilio():
    return {"ok":True}
