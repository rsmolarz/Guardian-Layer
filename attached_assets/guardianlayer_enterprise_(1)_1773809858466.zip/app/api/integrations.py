
from fastapi import APIRouter
import requests

router = APIRouter()

@router.get("/plaid")
def plaid():
    return {"status":"plaid placeholder"}

@router.get("/gmail")
def gmail():
    return {"status":"gmail placeholder"}

@router.get("/cloudflare")
def cloudflare():
    return {"status":"cloudflare placeholder"}
