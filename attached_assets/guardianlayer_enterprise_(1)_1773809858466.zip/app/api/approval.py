
from fastapi import APIRouter
router = APIRouter()

@router.post("/approve/{id}")
def approve(id:str):
    return {"approved":id}
